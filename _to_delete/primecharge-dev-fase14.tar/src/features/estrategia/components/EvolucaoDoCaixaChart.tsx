import { Area, AreaChart, CartesianGrid, XAxis, YAxis, Tooltip, ReferenceLine, ReferenceArea, ResponsiveContainer } from 'recharts';
import { Card, CardHeader, CardTitle, CardContent } from '@/shared/components/ui/card';
import { formatMoeda } from '@/shared/lib/format';
import { reamostrar } from '../lib/chartUtils';
import type { MesSimulado } from '../intelligence/simulacaoEmpresarial';

// Épico 3 — Central de Decisão Empresarial, Card 6 (Evolução do Caixa). Pedido do Carlos: "quero
// visualizar o comportamento de caixa caindo na compra, crescendo, caindo de novo" — por isso é
// um card à parte do Fluxo de Caixa (Card 2, que mostra 5 séries) e do Saldo Devedor×Patrimônio
// (Card 3, que é sobre dívida/patrimônio): aqui é só uma série, área cheia, pra ler a "respiração"
// do caixa num piscar de olhos. ReferenceLine em 0 deixa óbvio se o caixa chega a ficar negativo.
//
// 2026-08-10 — reserva mínima marcada no gráfico (Prioridade 4 da missão "copiloto financeiro"):
// linha tracejada na altura da reserva de segurança + área vermelha abaixo dela, pra "a operação
// vai consumir capital próprio" ser visual, não uma leitura de número contra número.
export function EvolucaoDoCaixaChart({ meses, reservaMinima }: { meses: MesSimulado[]; reservaMinima: number }) {
  const dados = reamostrar(meses, 60).map((m) => ({
    mes: m.mes,
    Caixa: Math.round(m.caixaDisponivel),
  }));

  const menorSaldo = Math.min(...meses.map((m) => m.caixaDisponivel));
  const menorSaldoOuReserva = Math.min(menorSaldo, reservaMinima, 0);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Evolução do caixa</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={dados} margin={{ left: 8, right: 16 }}>
            <defs>
              <linearGradient id="corCaixa" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.35} />
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" className="stroke-neutral-200 dark:stroke-neutral-800" />
            <XAxis dataKey="mes" tickFormatter={(v) => `M${v}`} fontSize={11} />
            <YAxis tickFormatter={(v) => formatMoeda(v)} fontSize={10} width={90} />
            <Tooltip formatter={(v) => formatMoeda(Number(v))} labelFormatter={(v) => `Mês ${v}`} />
            {/* Sempre montado (nunca {cond && <.../>}) — ver comentário equivalente no
                SaldoDevedorPatrimonioChart sobre o erro de reconciliação do Recharts.
                2026-08-13 — a ReferenceArea + ReferenceLine da reserva mínima estavam atrás de
                `{reservaMinima > 0 && (<>...</>)}`, ou seja: montavam/desmontavam 2 elementos
                juntos toda vez que a reserva de segurança ia de 0 pra >0 (ou vice-versa) — o
                mesmo padrão que travou o Card 2 (Fluxo de Caixa) com "insertBefore" (recharts
                issue #1723: variar a lista de filhos entre renders quebra a reconciliação interna
                dele). Agora os dois ficam sempre montados; quando reservaMinima é 0, só ficam
                com opacidade 0 e sem rótulo — invisíveis, mas presentes. */}
            <ReferenceLine y={0} stroke="#ef4444" strokeOpacity={menorSaldo < 0 ? 1 : 0} strokeDasharray="4 4" />
            <ReferenceArea y1={menorSaldoOuReserva} y2={reservaMinima} fill="#ef4444" fillOpacity={reservaMinima > 0 ? 0.08 : 0} />
            <ReferenceLine
              y={reservaMinima}
              stroke="#f59e0b"
              strokeOpacity={reservaMinima > 0 ? 1 : 0}
              strokeDasharray="4 4"
              label={reservaMinima > 0 ? { value: 'Reserva mínima', position: 'insideTopLeft', fontSize: 10, fill: '#f59e0b' } : undefined}
            />
            <Area type="monotone" dataKey="Caixa" stroke="#3b82f6" strokeWidth={2.5} fill="url(#corCaixa)" isAnimationActive={false} />
          </AreaChart>
        </ResponsiveContainer>
        {menorSaldo < 0 ? (
          <p className="mt-2 text-xs text-red-600 dark:text-red-400">
            O caixa fica negativo em algum ponto da simulação (mínimo de {formatMoeda(menorSaldo)}) — o cenário atual não é sustentável
            sem capital adicional ou ajuste nas premissas.
          </p>
        ) : (
          reservaMinima > 0 &&
          menorSaldo < reservaMinima && (
            <p className="mt-2 text-xs text-amber-600 dark:text-amber-400">
              Atenção. A operação começará a consumir capital próprio — o caixa chega a furar a reserva mínima ({formatMoeda(reservaMinima)}) em algum ponto da simulação.
            </p>
          )
        )}
      </CardContent>
    </Card>
  );
}
